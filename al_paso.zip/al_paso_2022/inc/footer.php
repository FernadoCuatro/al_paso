<footer id="footer">
 <div class="contenido-footer imagen-footer">
  <img src="imagenes/al-paso-white.png" alt="al-paso-white" />
 </div>
 <div class="contenido-footer footer-barra">
  <h2>NAVEGACIÓN</h2>
  <a href="index.php" class="footer-enlaces">Inicio</a><br />
  <a href="nosotros.php" class="footer-enlaces">Nosotros</a><br />
  <a href="categorias.php" class="footer-enlaces">Categorías</a><br />
  <a href="ofertas.php" class="footer-enlaces">Ofertas</a><br />
  <a href="atractores.php" class="footer-enlaces">Atractores</a><br /><br />
 </div>
 <div class="contenido-footer footer-social">
  <h2>CONTACTOS</h2><br />
  <div class="espacio-social">
   <a href="https://www.facebook.com/alpasosv503" target="_blank"><img src="imagenes/facebook-white.png" alt="facebook" class="imagen-social" /></a>
  </div>
  <div class="espacio-social">
   <a href="https://www.instagram.com/alpasosv/" target="_blank"><img src="imagenes/instagram-white.png" alt="instagram" class="imagen-social" /></a>
  </div>
  <div class="espacio-social">
   <a href="mailto:contacto.alpaso.sv@gmail.com" target="_blank"><img src="imagenes/email-white.png" alt="Email" class="imagen-social" /></a><br /><br /><br />
  </div>
 </div>
</footer>