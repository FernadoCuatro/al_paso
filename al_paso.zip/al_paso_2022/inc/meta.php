 <meta charset="UTF-8">
 <title>Bienvenidos - Al Paso</title>
 <link rel="shortcut icon" href="imagenes/al-paso.png" type="image/x-icon">
 <!-- APIs para utilizar fonts desde fonts.google -->
 <!-- La font ahora se podra accerder desde el archivo .css -->
 <!-- Hoja de estilos personalizados -->
 <link rel="stylesheet" type="text/css" href="css/estilos.css">
 <!-- Fin de estilos -->