-- TABLA ROL      [1/8]
CREATE TABLE rol
(
	id_rol               INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
	nombre_rol           VARCHAR(50)        NOT NULL,
	descripcion          TEXT								       NULL,
	estado_rol           VARCHAR(10)        NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- TABLA USUARIOS [2/8]
CREATE TABLE usuarios
(
	id_usuario           INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
	id_rol               INT                NOT NULL,
	nombre_usuario       VARCHAR(50)        NOT NULL,
	dui                  VARCHAR(20)        NOT NULL,
	nit                  VARCHAR(20)        NOT NULL,
	telefono             VARCHAR(15)        NOT NULL,
	correo               VARCHAR(30)        NOT NULL,
	password             VARCHAR(200)       NOT NULL,
	estado_usuario       CHAR(2)            NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- TABLA USUARIOS [3/8]
CREATE TABLE categoria
(
	id_categoria         INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
	nombre_categoria     VARCHAR(30)        NOT NULL,
	descripcion          TEXT               NULL,
	estado_categoria     VARCHAR(10)        NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- TABLA USUARIOS [4/8]
CREATE TABLE productos
(
	id_producto          INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
	id_categoria         INT                NOT NULL,
	codigo_producto      VARCHAR(10)        NOT NULL,
	nombre_producto      VARCHAR(50)        NOT NULL,
	precio_producto      DECIMAL(6,2)       NOT NULL,
	fecha_fabricacion    DATE               NOT NULL,
	fecha_expiracion     DATE               NOT NULL,
	img_producto         VARCHAR(50)        NOT NULL,
	descripcion          TEXT               NULL,
	estado_producto      CHAR(2)            NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- TABLA USUARIOS [5/8]
CREATE TABLE facturas
(
	id_factura           INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
	id_usuario           INT                NOT NULL,
	fecha                DATETIME           NOT NULL,
	total_factura        DECIMAL(6,2)       NOT NULL,
	estado_factura       CHAR(2)            NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- TABLA USUARIOS [6/8]
CREATE TABLE pagos
(
	id_pago              INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
	id_factura           INT                NOT NULL,
	fecha                DATETIME           NOT NULL,
	metodo_pago          VARCHAR(30)        NOT NULL,
	total_pago           DECIMAL(6,2)       NOT NULL,
	descuento            INT                NOT NULL,
	pago_cliente         DECIMAL(6,2)       NOT NULL,
	total_vuelto         DECIMAL(6,2)       NOT NULL,
	descripcion          TEXT               NULL,
	estado_pago          CHAR(2)            NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- TABLA USUARIOS [7/8]
CREATE TABLE comentarios
(
	id_comentarios       INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
	id_pago              INT                NOT NULL,
	fecha                DATETIME           NOT NULL,
	calificacion         INT                NOT NULL,
	comentario           TEXT               NULL,
	estado_comentario    CHAR(2)            NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- TABLA USUARIOS [8/8]
CREATE TABLE facturas_productos
(
	id_contenido_factura INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
	id_factura           INT                NOT NULL,
	id_producto          INT                NOT NULL,
	cantidad             INT                NOT NULL,
	total_producto       DECIMAL(6,2)       NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- ----------------------------------------------
-- DEFINIMOS LAS RELACIONES DE LA BASE DE DATOS CON LAS TABLAS
-- ----------------------------------------------

-- RELACIONAMOS LA TABLA ROL CON LA TABLA USUARIOS
ALTER TABLE usuarios ADD CONSTRAINT Fk_usuarios_rol FOREIGN KEY(id_rol) REFERENCES rol(id_rol);

-- RELACIONAMOS LA TABLA USUARIO CON LA TABLA FACTURAS
ALTER TABLE facturas ADD CONSTRAINT FK_facturas_usuarios FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario);

-- RELACIONAMOS LA TABLA FACTURAS_PRODUCTOS
-- CON LA TABLA FACTURAS
ALTER TABLE facturas_productos ADD CONSTRAINT FK_facturas_productos_facturas FOREIGN KEY (id_factura) REFERENCES facturas(id_factura);
-- CON LA TABLA PRODUCTOS
ALTER TABLE facturas_productos ADD CONSTRAINT FK_facturas_productos_productos FOREIGN KEY (id_producto) REFERENCES productos(id_producto);

-- RELACIONAMOS LA TABLA PAGOS CON LA TABLA FACTURAS
ALTER TABLE pagos ADD CONSTRAINT FK_pago_facturas FOREIGN KEY (id_factura) REFERENCES facturas(id_factura);

-- RELACIONAMOS LA TABLA PRODUCTOS CON LA TABLA CATEGORIA
ALTER TABLE productos ADD CONSTRAINT FK_productos_caterias FOREIGN KEY (id_categoria) REFERENCES categoria(id_categoria);

-- RELACIONAMOS LA TABLA COMENTARIO CON LA TABLA PAGOS
ALTER TABLE comentarios ADD CONSTRAINT FK_comentarios_pago FOREIGN KEY (id_pago) REFERENCES pagos(id_pago);

-- ----------------------------------------------
-- INSERT INTO NECESARIOS
-- ----------------------------------------------

-- ----------------------------------------------
-- TABLA => categoria
-- ----------------------------------------------
INSERT INTO categoria(id_categoria, nombre_categoria, descripcion, estado_categoria) VALUES 
(null,'Comida rapida','Disfruta las mejores comidas rapidas con nosotros','A'),
(null,'Snacks','Disfruta los mejores snacks con nosotros','A'),
(null,'Bebidas','Disfruta las mejores bebidas con nosotros','A');

-- ----------------------------------------------
-- TABLA => rol
-- ----------------------------------------------
INSERT INTO rol(id_rol, nombre_rol, descripcion, estado_rol) VALUES 
(null,'Vendedor','Gestiona las responsabilidades del vendedor.','A'),
(null,'Gerente','Gestiona las responsabilidades del gerente.','A'),
(null,'Administrador','Gestiona las responsabilidades del administrador.','A');

-- ----------------------------------------------
-- TABLA => usuarios
-- ----------------------------------------------
INSERT INTO usuarios(id_usuario, id_rol, nombre_usuario, dui, nit, telefono, correo, password, estado_usuario) VALUES 
-- Acceso para Vendedor
-- melanie@alpaso.com 
-- vendedor?+al
(null,1,'Melanie Moreno Echeverria','00000000-0','0000-000000-000-0','770-518-9050','melanie@alpaso.com','c39b591a28a1b9b16aae766d9ae9d68077e9712b78735b0d62ce148479c05108806b943f2ebeb8268940208189e13aaa3ed51a4818e229cdc3dc8018574402b5', 'A'),
-- Acceso para Gerente
-- alejandro@alpaso.com 
-- gerente?+pa
(null,2,'Alejandro Carranza Arias','00000000-0','0000-000000-000-0','602-876-8686','alejandro@alpaso.com','3ae8fb4c303877d5a489f80ee7ce4d8ed9fce4e2eb64ad172839010d3b9f291b072702600711c14bf4cd81b3915cc37faac55300ca87161d083e8655f8b1a697', 'A'),
-- Acceso para Administrador 
-- melissa@alpaso.com 
-- administrador?+so
(null,3,'Melissa Lopez Escobar','00000000-0','0000-000000-000-0','607-569-6471','melissa@alpaso.com','5bdd848af11e64f1a470e5e33c7b7d39d28d063116f34baddf945f77231259366211e73042e78157a5eddbf37467352417c3dd14eb579e8c97dad234dd1d96bf', 'A'),
-- carlos@alpaso.com 
-- messibalondeoro
(null,1,'Carlos Andres Montes','00000000-0','0000-000000-000-0','408-538-5354','carlos@alpaso.com','8cac3f8265c60a27acd0b5feaf236fa6de71b4eabf5b9847c963fb3ad749c566e4dd902cabfd10c8f9855467af12293a3e7ce73d2c6787be08621922d7a76af0','A'),
-- wilburnjgibson@alpaso.com 
-- %AnW9jEYd
(null,1,'Mark Keller','00000000-0','0000-000000-000-0','270-739-2905','wilburnjgibson@alpaso.com','421ed426f43cd1b9f5e704a1d5db972dd6b2ec6468fef8fbe285471821e5b30dab7964237c84dff8c57202dbb4365c4cb32e72105c05011504a6c21c93cdc50d','A'),
-- theodorelattin@alpaso.com 
-- GyjhTYCk#
(null,2,'Theodore Lattin','00000000-0','0000-000000-000-0','626-657-8310','theodorelattin@alpaso.com','9511440fcac660263a7a278abcb5cba6104052f915d96c6dd50d4ec7ce765d337a8202a1b32858599bb9ed2b9db0fee64b28f562947acd2542d4bfb3cd6a5e23','A'),
-- dorissmith@alpaso.com 
-- Xfxiz6P%&
(null,3,'Doris Smith','00000000-0','0000-000000-000-0','952-406-1032','dorissmith@alpaso.com','fe12323bf14bcc21dbb3b36299ccde3c2c9625f5c1b9f1f3b0665d5ef5f96887eba4a0e3c570a679e144ce4f5ec8f807d18c70d5eb81a3335ccb6fc3570abec6','A'),
-- maryweber@alpaso.com 
-- tMyb4By@!
(null,1,'Mary Weber','00000000-0','0000-000000-000-0','925-476-6111','maryweber@alpaso.com','52d4fe633a7310a4391ea754f14c9cd8d5beb699bfe5e6309aa9050e7e94d97c025083c77fffe06c91359491b64c072203d29f1d1a6c6af7b8be4faf80f40c9e','A'),
-- vickiestanton@alpaso.com 
-- x$%au^OwJ
(null,2,'Vickie Stanton','00000000-0','0000-000000-000-0','708-448-4439','vickiestanton@alpaso.com','cafd9b628a02c17be6571b6435de964e8c953c8127aa413b1344d4923848905cda6fe427f42c635ce488a685dc914879a7a95fc442bc342f9e14f2eb679bf8af','A'),
-- tyronschoonover@alpaso.com 
-- kNf*^&reE
(null,3,'Tyron Schoonover','00000000-0','0000-000000-000-0','617-684-7206','tyronschoonover@alpaso.com','5e010c44f5673c3d61c7788daf4ec488d8da3a906938ae6c6e1ab289b7f2dd9fbfafdd86fa5ab90b3bbd57d256f4233e6b810f05cc00d03b8581bc34a5d6e749','A');

-- ----------------------------------------------
-- TABLA => productos
-- ----------------------------------------------
INSERT INTO productos (id_producto, id_categoria, codigo_producto, nombre_producto, precio_producto, fecha_fabricacion, fecha_expiracion, img_producto, descripcion, estado_producto) VALUES
(null, 1, 'MA403', 'Maruchan', '0.78', '2021-09-23', '2022-12-11', 'maruchan.png', 'Sopa Maruchan Ramen de harina de trigo para preparar sopa instantanea sabor a camaron, limon y habanero.', 'A'),
(null, 2, 'PG03L', 'Papas pringles', '3.98', '2021-01-12', '2021-12-29', 'pringles.jpg', 'Obten una lata para experimentar el sabor de la crema agria y la cebolla y el crujido satisfactorio de las patatas fritas Pringles.', 'A'),
(null, 3, 'AEL001', 'Aloe vera', '1.89', '2021-11-23', '2021-02-21', 'aloe.jpg', 'Elige productos naturales libres de preservantes y colores artificiales. Elige la bebida aloe vera sabor original. Tambien sin azucar.', 'A'),
(null, 1, 'PZ823', 'Pizza de jamon', '3.50', '2021-11-03', '2021-12-11', '15-Minute-Pizza-WS-Thumbnail.png', 'Pizza clasica de jamon ', 'A'),
(null, 2, 'RCH923', 'Ranch natural', '0.74', '2021-11-17', '2021-12-17', '7212830104.jpg', 'Rachita naturales', 'A'),
(null, 2, '7212823010', 'Cheetos quezo', '0.92', '2021-11-02', '2021-12-04', '72128230104.jpg', 'Cheetos con extra quezo, color azul.', 'A'),
(null, 3, '7318090019', 'Salva Cola', '0.25', '2021-08-13', '2022-04-02', '73180900198.jpg', 'Salvacola clasica ', 'A'),
(null, 3, '7318090019', 'Kolashampan', '0.32', '2021-11-06', '2021-12-04', '73180900199.jpg', 'Kolashampan, lo mejor de la vida.', 'A'),
(null, 2, '7487571011', 'Galleta picnic', '1.21', '2021-11-04', '2022-03-26', '74875710111.jpg', 'Paquete de galleta picnic', 'A'),
(null, 2, '7575280135', 'Takis', '0.67', '2021-07-16', '2022-04-30', '75752801350.jpg', 'Takis de los azulitos extra juego', 'A'),
(null, 3, '7411602702', 'Pepsi', '1.10', '2021-07-10', '2022-04-22', '741160270238.jpg', 'Pepsi en version mediana ', 'A'),
(null, 2, '7487570200', 'Nachos', '0.46', '2021-11-11', '2022-04-23', '748757020022.jpg', 'Nachos de la diana', 'A'),
(null, 3, '7501791631', 'Agua', '0.25', '2021-08-12', '2022-05-07', '750179163118.jpg', 'Agua natural, compre.', 'A'),
(null, 1, 'air-23242', 'Hamburguesa CN', '3.74', '2021-11-17', '2021-12-18', 'air-fryer-frozen-burgers-sq.jpg', 'Hamburguesa de carne ', 'A'),
(null, 1, 'hot-dogs6', 'Hotdog cls', '2.63', '2021-11-04', '2022-02-19', 'air-fryer-hot-dogs6.jpg', 'Hotdog clasico, con mucho sabor.', 'A'),
(null, 1, 'papasw3324', 'Papas fritas', '1.02', '2021-11-14', '2021-12-10', 'papasfritas.jpg', 'Papas fritas tradiccionales mejores que las del macdonals', 'A'),
(null, 1, 'prod243242', 'Pizza personal', '4.89', '2021-11-05', '2021-12-11', 'products-delacasa500x5008.png', 'Pizza de jamon, peperoni y todo lo que debe llevar.', 'A'),
(null, 1, 'r_1676_145', 'Hamburguesa PLL', '3.73', '2021-11-07', '2021-12-12', 'r_1676_1455638770.jpg', 'Hamburguesas de pollo completamente buenas.', 'A'),
(null, 1, 'R12-17257', 'Alitas de pollo', '1.34', '2021-09-17', '2022-01-22', 'R12-17257.jpg', 'Alitas de pollos con todo el sabor, solo para comprar.', 'A'),
(null, 1, 'sanduch3s4', 'Sandwich ', '0.78', '2021-11-10', '2021-12-04', 'sanduche.png', 'Sandwich de jamon, esta bueno.', 'A'),
(null, 1, 'TC0242', 'Tacos de carne', '2.89', '2021-11-06', '2021-12-11', 'tacoblando_as_188020662.jpg', 'La promocion incluye a tres tacos', 'A'),
(null, 3, '99985E26', 'Crema soda', '0.74', '2021-11-14', '2022-03-27', '99985E26-668A.jpeg', 'De las mejores sabores que existen', 'A');

-- ----------------------------------------------
-- TABLA => facturas
-- ----------------------------------------------
INSERT INTO facturas (id_factura, id_usuario, fecha, total_factura, estado_factura) VALUES
(null, 1, '2021-11-24 22:55:32', '21.23', 'I'),
(null, 1, '2021-11-24 23:05:15', '4.55', 'I'),
(null, 1, '2021-11-24 23:06:07', '5.24', 'I'),
(null, 1, '2021-11-28 19:47:47', '13.62', 'I'),
(null, 1, '2021-11-29 09:40:48', '6.20', 'I'),
(null, 1, '2021-11-29 09:44:09', '1.03', 'I'),
(null, 1, '2021-11-29 18:07:53', '1.24', 'I'),
(null, 1, '2021-11-29 19:15:50', '5.85', 'I'),
(null, 4, '2021-11-29 19:29:16', '11.74', 'I'),
(null, 1, '2021-11-30 22:02:14', '2.63', 'I');

-- ----------------------------------------------
-- TABLA => facturas_productos
-- ----------------------------------------------
INSERT INTO facturas_productos (id_contenido_factura, id_factura, id_producto, cantidad, total_producto) VALUES
(null, 1, 19, 2, '9.78'),
(null, 1, 7, 4, '3.68'),
(null, 1, 9, 4, '1.28'),
(null, 1, 8, 1, '0.25'),
(null, 1, 2, 1, '3.98'),
(null, 1, 15, 1, '0.25'),
(null, 1, 12, 3, '2.01'),
(null, 2, 2, 1, '3.98'),
(null, 2, 9, 1, '0.32'),
(null, 2, 15, 1, '0.25'),
(null, 3, 14, 1, '0.46'),
(null, 3, 3, 1, '1.89'),
(null, 3, 21, 1, '2.89'),
(null, 4, 16, 3, '11.22'),
(null, 4, 7, 1, '0.92'),
(null, 4, 22, 2, '1.48'),
(null, 5, 18, 3, '3.06'),
(null, 5, 12, 1, '0.67'),
(null, 5, 15, 1, '0.25'),
(null, 5, 22, 3, '2.22'),
(null, 6, 1, 1, '0.78'),
(null, 6, 8, 1, '0.25'),
(null, 7, 7, 1, '0.92'),
(null, 7, 9, 1, '0.32'),
(null, 8, 21, 1, '2.89'),
(null, 8, 5, 1, '0.74'),
(null, 8, 22, 3, '2.22'),
(null, 9, 9, 1, '0.32'),
(null, 9, 4, 3, '10.50'),
(null, 9, 7, 1, '0.92'),
(null, 10, 17, 1, '2.63');

-- ----------------------------------------------
-- TABLA => pagos
-- ----------------------------------------------
INSERT INTO pagos (id_pago, id_factura, fecha, metodo_pago, total_pago, descuento, pago_cliente, total_vuelto, descripcion, estado_pago) VALUES
(null, 1, '2021-11-24 22:56:16', 'Efectivo', '20.17', 5, '25.00', '4.83', 'Proceso finalizado', 'C'),
(null, 3, '2021-11-24 23:06:31', 'Efectivo', '5.24', 0, '10.00', '4.76', 'No se aplico descuento ', ''),
(null, 4, '2021-11-28 19:49:36', 'Efectivo', '12.94', 5, '15.00', '2.06', 'El proceso se realizo con exito ', 'C'),
(null, 5, '2021-11-29 09:42:00', 'Electrónico', '6.20', 0, '6.20', '0.00', 'El proceso finalizo ', 'C'),
(null, 6, '2021-11-29 09:46:06', 'Efectivo', '0.98', 5, '1.00', '0.02', 'Se realizo con exito ', 'C'),
(null, 2, '2021-11-29 18:09:07', 'Efectivo', '4.55', 0, '5.00', '0.45', 'Se realizo con exito ', 'C'),
(null, 8, '2021-11-29 19:17:22', 'Efectivo', '5.56', 5, '10.00', '4.44', 'Se finalizo con exito', 'C'),
(null, 9, '2021-11-29 19:29:36', 'Efectivo', '11.74', 0, '20.00', '8.26', 'Se finalizo', 'C'),
(null, 7, '2021-11-30 21:59:25', 'Electrónico', '1.24', 0, '1.24', '0.00', 'Se finalizo', 'C'),
(null, 10, '2021-11-30 22:02:52', 'Efectivo', '2.50', 5, '5.00', '2.50', 'Se proceso bien', 'C');

-- ----------------------------------------------
-- TABLA => comentarios
-- ----------------------------------------------
INSERT INTO comentarios (id_comentarios, id_pago, fecha, calificacion, comentario, estado_comentario) VALUES
(null, 4, '2021-11-29 09:42:45', 7, 'Estuvo bien', 'L'),
(null, 7, '2021-11-29 19:18:44', 5, 'El proceso fue lento', 'L'),
(null, 9, '2021-11-30 22:00:03', 9, 'Se realizo rapido ', 'L'),
(null, 10, '2021-11-30 22:03:20', 6, 'No fue muy rapido ', 'L'),
(null, 1, '2021-11-24 22:56:16', 9, 'Buen personal', 'L'),
(null, 2, '2021-11-24 22:56:16', 9, 'Buen personal', 'L'),
(null, 3, '2021-11-24 23:06:31', 4, 'Se tardaron', 'L'),
(null, 5, '2021-11-29 09:42:00', 9, 'El trato fue bueno', 'L'),
(null, 6, '2021-11-29 09:46:06', 10, 'Volvere pronto, graciaaas.', 'L'),
(null, 8, '2021-11-29 19:17:22', 7, 'Pueden mejorar', 'L');