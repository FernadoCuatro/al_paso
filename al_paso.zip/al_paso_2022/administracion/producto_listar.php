<?php
require_once 'config/conexion.php';
include 'config/funciones.php';
comprobar_sesion();
comprobar_rol_gerente();

$statement="SELECT id_producto, nombre_categoria, codigo_producto, nombre_producto, precio_producto, fecha_fabricacion, fecha_expiracion, img_producto, p.descripcion, estado_producto FROM productos p inner join categoria c on c.id_categoria = p.id_categoria";
$resultado= $conexion->query($statement) or die (mysqli_error($conexion));
?>

<!DOCTYPE html>
<html lang="es">

<head>
 <?php require 'inc/meta.php'; ?>
</head>

<body>
 <div id="vista">
  <?php require 'inc/header.php'; ?>
  <!-- Contenido general -->
  <div id="contenido-general">
   <?php require 'inc/header_superior.php'; ?>

   <!-- Espacio para el contenido a agregar -->
   <div class="container-fluid">
    <div class="contenido-entrada">

     <article class="texto-base">
      <h1 class="nombre-proceso">Lista de Productos</h1>
      <h4 class="nombre-modulo">Módulo Producto</h4>
     </article>

    <div class="text-center">
     <a href="producto_crear.php" class="btn-add"><i class="fas fa-plus-square"></i> Añadir productos</a>
    </div>

    <div class="contenedor-tabla">
     <table class="contenedor-datos">
      <thead>
       <tr>
       <th></th>
       <th class="text-center">Categoría</th>
       <th>Código</th>
       <th>Nombre</th>
       <th>Precio</th>
       <th>Fabricación -<br/>Vencimiento</th>
       <th>Imagen</th>
       <th>Descripción</th>
       <th>Estado</th>
       <th></th>
       </tr>
      </thead>
      <tbody>
       <?php foreach ($resultado as $producto): ?>
        <tr class="formato-celda formato-producto">
         <td class="text-center"><?php echo $producto['id_producto']; ?></td> 
         <td class="text-center"><?php echo $producto['nombre_categoria']; ?></td>
         <td><?php echo $producto['codigo_producto']; ?></td>
         <td><?php echo $producto['nombre_producto']; ?></td>
         <td>$<?php echo $producto['precio_producto']; ?></td>
         <td><?php echo $producto['fecha_fabricacion']; ?> -<br/><?php echo $producto['fecha_expiracion']; ?></td>
         <td class="formato-pago"><img src="img_productos/<?php echo $producto['img_producto']; ?>" alt="<?php echo $categoria['img_producto']; ?>" style="width: 95%;"></td>
         <td class="formato-pago formato-descripcion"><?php echo $producto['descripcion']; ?></td>
         <td class="text-center">
         <?php if ($producto['estado_producto']=='A'): ?>
           <?= "Activo" ?>
          <?php else: ?>
           <?= "Inactivo" ?>
          <?php endif ?>
         </td>
          <td>
           <a class="editar" href="producto_editar.php?id_producto=<?= $producto['id_producto']; ?>"><i class="fas fa-marker"></i></a>
           <a class="borrar" href="#" onclick="preguntar(<?php echo $producto['id_producto']?>)"><i class="far fa-trash-alt"></i></a>
         </td>
        </tr>
       <?php endforeach ?>
      </tbody>
     </table>
    </div>

   </div>
  </div>
  </div>
 </div>

<script type="text/javascript">
  function preguntar(id){
    if(confirm('¿Estás seguro que deseas borrar el producto?')){
        window.location.href = "producto_eliminar.php?id_producto="+id;
    }
  }
</script>

 <?php mysqli_close($conexion); ?>
<?php require 'inc/scripts.php'; ?>
</body>

</html>