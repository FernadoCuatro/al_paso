<?php 
session_start();

session_destroy();
$_SESSION = [];

header('Location: ../administracion.php?salir=on');
die();
?>