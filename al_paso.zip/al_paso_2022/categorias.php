<!DOCTYPE html>
<html lang="es">
<head>
 <?php require 'inc/meta.php'; ?>
</head>
<body>
 <!-- ESTRUCTURA 1 | BARRA DE NAVEGACION -->
 <?php require 'inc/header.php'; ?>

 <!-- ESTRUCTURA 4 | CATEGORIAS -->
 <section id="categorias">
  <div class="texto-categoria">
   <h1>Categorías</h1>
  </div>
  <div class="imagen-bebida-categoria">
   <img src="imagenes/new-bebida.png" class="imagen-bebida" alt="Bebidas" />
  </div>
  <div class="imagen-food-categoria">
   <img src="imagenes/new-food.png" class="imagen-new-food" alt="Comida rapida" />
  </div>
  <div class="imagen-snacks-categoria">
   <img src="imagenes/new-snacks.png" class="imagen-snacks" alt="Snacks" />
  </div>
  <div class="bebidas">
   <h2>Bebidas</h2>
  </div>
  <div class="comida-rapida">
   <h2>Comida rápida</h2>
  </div>
  <div class="snacks">
   <h2>Snacks</h2>
  </div>
 </section>

 <!-- ESTRUCTURA 6 | FO0TER / PIE DE PAGINA -->
 <?php require 'inc/footer.php'; ?>
</body>
</html>