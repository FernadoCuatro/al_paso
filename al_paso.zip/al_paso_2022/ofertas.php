<!DOCTYPE html>
<html lang="es">
<head>
 <?php require 'inc/meta.php'; ?>
</head>
<body>
 <!-- ESTRUCTURA 1 | BARRA DE NAVEGACION -->
 <?php require 'inc/header.php'; ?>

 <!-- ESTRUCTURA 5 | OFERTAS -->
 <div id="ofertas">
  <div>
   <div id="div1" class="offert-izquieda">
    <img class="gif-oferta" src="imagenes/gif-oferta.gif" />
    <img class="alpaso-offer" src="imagenes/al-paso-offer.png" />
   </div>
  </div>
  <div id="combo">
   <div class="combos">
    <br>
    <img class="combos-imagenes" src="imagenes/combo1.png" />
    <br>
   </div>
   <div class="combos">
    <br>
    <img class="combos-imagenes" src="imagenes/combo2.png" />
    <br>
   </div>
   <div class="combos">
    <br>
    <img class="combos-imagenes" src="imagenes/combo3.png" />
    <br>
   </div>
  </div>
  <br>
 </div>

 <!-- ESTRUCTURA  | FORMA DE PAGO -->
 <div id="forma-pago">
  <div>
   <div class="encabezado-pago">
    <h1>Formas de pago</h1>
   </div>
  </div>
  <div id="colum-pago">
   <div class="celda-forma-pago1">
    <img class="imagen-forma-pago" src="imagenes/efectivo.png" alt="efectivo">
    <b>
     <p>Efectivo</p>
    </b>
   </div>
   <div class="celda-forma-pago3">
    <img class="imagen-forma-pago" src="imagenes/tarjeta.png" alt="tarjeta">
    <b>
     <p>Tarjetas de crédito o débito</p>
    </b>
   </div>
  </div>
 </div>

 <!-- ESTRUCTURA 6 | FO0TER / PIE DE PAGINA -->
 <?php require 'inc/footer.php'; ?>
</body>
</html>