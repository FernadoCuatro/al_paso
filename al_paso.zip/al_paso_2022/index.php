<!DOCTYPE html>
<html lang="es">
<head>
 <?php require 'inc/meta.php'; ?>
</head>
<body>
 <!-- ESTRUCTURA 1 | BARRA DE NAVEGACION -->
 <?php require 'inc/header.php'; ?>

  <!-- ESTRUCTURA 2 | INICIO -->
  <section id="inicio">
   <div class="texto-presentacion">
    <h1>al paso</h1>
    <h3>donde tu vayas, estamos contigo</h3>
   </div>
   <div class="imagen-presentacion">
    <img src="imagenes/al-paso.png" alt="al-paso" />
   </div>
  </section>
  
 <!-- ESTRUCTURA 6 | FO0TER / PIE DE PAGINA -->
 <?php require 'inc/footer.php'; ?>
</body>
</html>