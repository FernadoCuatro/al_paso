<meta charset="UTF-8">
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Estilos utilizados para Bootstrap -->
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
<!-- Estilos personalizados -->
<link rel="stylesheet" type="text/css" href="./css/styles.css">
<title>Administración - Al paso</title>