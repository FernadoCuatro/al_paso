<?php
require_once 'config/conexion.php';
include 'config/funciones.php';
comprobar_sesion();
comprobar_rol_administrador();

$statement="SELECT id_usuario, r.nombre_rol, nombre_usuario, dui, telefono, correo, estado_usuario FROM usuarios u inner join rol r on u.id_rol = r.id_rol;";
$resultado= $conexion->query($statement) or die (mysqli_error($conexion));
?>

<!DOCTYPE html>
<html lang="es">

<head>
 <?php require 'inc/meta.php'; ?>
</head>

<body>
 <div id="vista">
  <?php require 'inc/header.php'; ?>
  <!-- Contenido general -->
  <div id="contenido-general">
   <?php require 'inc/header_superior.php'; ?>

   <!-- Espacio para el contenido a agregar -->
   <div class="container-fluid">
    <div class="contenido-entrada">

     <article class="texto-base">
      <h1 class="nombre-proceso">Lista de usuarios</h1>
      <h4 class="nombre-modulo">Módulo usuario</h4>
     </article>

    <div class="text-center">
     <a href="usuario_crear.php" class="btn-add"><i class="fas fa-plus-square"></i> Añadir usuario</a>
    </div>

    <div class="contenedor-tabla">
     <table class="contenedor-datos">
      <thead>
       <tr>
       <th></th>
       <th class="text-center">Rol</th>
       <th>Nombre</th>
       <th>DUI</th>
       <th>Teléfono</th>
       <th>Correo electrónico</th>
       <th>Estado</th>
       <th></th>
       </tr>
      </thead>
      <tbody>
       <?php foreach ($resultado as $usuario): ?>
        <tr class="formato-celda">
         <td><?php echo $usuario['id_usuario']; ?></td> 
         <td class="text-center"><?php echo $usuario['nombre_rol']; ?></td> 
         <td><?php echo $usuario['nombre_usuario']; ?></td>
         <td><?php echo $usuario['dui']; ?></td>
         <td><?php echo $usuario['telefono']; ?></td>
         <td><?php echo $usuario['correo']; ?></td>

         <td>
         <?php if ($usuario['estado_usuario']=='A'): ?>
           <?= "Activo" ?>
          <?php else: ?>
           <?= "Inactivo" ?>
          <?php endif ?>
         </td>
          <td>
           <a class="editar" href="usuario_editar.php?id_usuario=<?= $usuario['id_usuario']; ?>"><i class="fas fa-marker"></i></a>
           <a class="borrar" href="#" onclick="preguntar(<?php echo $usuario['id_usuario']?>)"><i class="far fa-trash-alt"></i></a>
         </td>
        </tr>
       <?php endforeach ?>
      </tbody>
     </table>
    </div>
   </div>
  </div>
  </div>
 </div>

<script type="text/javascript">
  function preguntar(id){
    if(confirm('¿Estás seguro que deseas borrar el usuario?')){
        window.location.href = "usuario_eliminar.php?id_usuario="+id;
    }
  }
</script>

<?php mysqli_close($conexion); ?>
<?php require 'inc/scripts.php'; ?>
</body>

</html>