<?php
include 'config/funciones.php';
comprobar_sesion();
comprobar_rol_administrador();

if($_SERVER['REQUEST_METHOD']=='POST'){
 require_once 'config/conexion.php';

 $usuario_rol      = $_POST['usuario_rol'];
 $usuario_nombre   = $_POST['usuario_nombre'];
 $usuario_dui      = $_POST['usuario_dui'];
 $usuario_nit      = $_POST['usuario_nit'];
 $usuario_telefono = $_POST['usuario_telefono'];
 $usuario_email    = $_POST['usuario_email'];
 $usuario_pw       = $_POST['usuario_pw'];
 $usuario_pw       = hash('sha512' , $usuario_pw);
 $usuario_estado   = 'A';

 try {
  $sentencia="INSERT INTO usuarios(id_usuario, id_rol, nombre_usuario, dui, nit, telefono, correo, password, estado_usuario) 
  VALUES (null, '$usuario_rol', '$usuario_nombre', '$usuario_dui', '$usuario_nit', '$usuario_telefono', '$usuario_email', '$usuario_pw', '$usuario_estado');";
  
  $conexion->query($sentencia) or die (mysqli_error($conexion));

  header('location: usuario_listar.php');

 } catch (Exception $e) {
  header('location: usuario_listar.php');
 }

 mysqli_close($conexion);
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
 <?php require 'inc/meta.php'; ?>
</head>

<body>
 <div id="vista">
  <?php require 'inc/header.php'; ?>
  <!-- Contenido general -->
  <div id="contenido-general">
   <?php require 'inc/header_superior.php'; ?>

   <!-- Espacio para el contenido a agregar -->
   <div class="container-fluid">
    <div class="contenido-entrada">
     <article class="texto-base">
      <h1 class="nombre-proceso">Crear usuario</h1>
      <h4 class="nombre-modulo">Módulo usuario</h4>
     </article>
     <!-- Todo listo, mucha suerte; recuerda las indicaciones. -->
     <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" class="formulario" id="fowrmulario">
      <div class="form-group">
       <label for="Rol">Rol establecido al usuario:</label>
       <div class="form-group-rol">
        <select name="usuario_rol" id="usuario_rol" class="usuario_rol">
         <option disabled selected=" ">Seleccione Rol</option>
         <option value="3">Administrador</option>
         <option value="2">Gerente</option>
         <option value="1">Vendedor</option>
        </select>
       </div>
      </div>
      <br><br><br><br><br>
      <!--Primer bloque ira Nombre y correo-->
      <div class="primer-bloque">
       <!--encabezados nombre,correo-->
       <div>
        <label for="Nombre" class="form-label-nombre">Nombre Completo:</label>
       </div>
       <div>
        <label for="correo" class="form-label-correo">Correo Electrónico:</label>
       </div>
       <!--Inputs nombre,correo-->
       <div class="form-inputs-nombre">
        <input type="text" name="usuario_nombre" id="usuario_nombre" class="usuario_nombre" onkeypress="validarNombre(this,10)" minlength="10" maxlength="50" placeholder="Nombre completo">
        <p class="campos_alerta" id="alertanombre"></p>
       </div>
       <div class="form-inputs-correo">
        <input type="mail" name="usuario_email" id="usuario_email" class="usuario_email" onkeypress="validarcorreo(this)" placeholder="correo@alpaso.com">
        <p class="campos_alerta" id="alertacorreo"></p>
       </div>
      </div>
      <!--Segundo bloque ira dui,nit y telefono-->
      <div class="segundo-bloque">
       <!--encabezados dui,nit,telefono-->
       <div>
        <label for="Dui" class="form-label-dui">DUI:</label>
       </div>
       <div>
        <label for="Nit" class="form-label-nit">NIT:</label>
       </div>
       <div>
        <label for="Telefono" class="form-label-telefono">Telefono:</label>
       </div>
       <!--Inputs dui,nit,telefono-->
       <div class="form-inputs-dui">
        <input type="text" name="usuario_dui" id="usuario_dui" class="usuario_dui " required="on" onkeypress="this.value=mascarardui(this.value)" maxlength="10" placeholder="00000000-0">
       </div>
       <div class="form-inputs-nit">
        <input type="text" name="usuario_nit" id="usuario_nit" class="usuario_nit" required="on" onkeypress="this.value=mascaranit(this.value)" maxlength="17" placeholder="0000-00000-000-0">
       </div>
       <div class="form-inputs-telefono">
        <input type="text" name="usuario_telefono" id="usuario_telefono" class="usuario_telefono" required="on" onkeypress="this.value=mascaratelefono(this.value)" onblur="validartelefono(this,8)" maxlength="9" placeholder="0000-0000">
       </div>
       <!--Parrafos dui,nit,telefono-->
       <div class="form-parrafo-dui">
        <p class="campos_alerta" id="alertadui"></p>
       </div>
       <div class="form-parrafo-nit">
        <p class="campos_alerta" id="alertanit"></p>
       </div>
       <div class="form-parrafo-telefono">
        <p class="campos_alerta" id="alertatelefono"></p>
       </div>
      </div>
      <!--tercer bloque ira contra 1 -->
      <div class="tercer-bloque">
       <!--encabezado Contraseña-->
       <div>
        <label for="Password" class="form-label-password">Contraseña:</label>
       </div>
       <!--Input contraseña -->
       <div class="form-inputs-contraseña">
        <input type="Password" name="usuario_pw" id="usuario_pw" class="usuario_pw" onkeyup="validarcontra(this,5)" minlength="5" required="on" placeholder="************">
       </div>
       <div class="form-parrafo-contraseña">
        <p class="campos_alerta" id="alertacontraseña"></p>
       </div>
      </div>
      <!--encabezado repetir contraseña-->
      <div class="form-group-contraseña2">
       <label for="Password2" class="form-label-password2">Repetir Contraseña:</label>
       <!--Input contraseña -->
       <div class="form-inputs-contraseña2">
        <input type="Password" name="usuario_rept" id="usuario_rept" class="usuario_rept " onkeyup="validarcontraseña2(this,5)" required="on" placeholder="************">
       </div>
       <div class="form-parrafo-contraseña-2">
        <p class="campos_alerta" id="alertacontraseña2"></p>
       </div>
       <div class="form-button-guardar">
        <button type="submit" class="envio" id="envio">Guardar</button>
       </div>
      </div>
     </form>

    <div class="text-center">
     <a href="usuario_listar.php">Volver</a>
    </div>
    </div>
   </div>
  </div>
 </div>

<?php require 'inc/scripts.php'; ?>
</body>

</html>