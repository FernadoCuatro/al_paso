<?php
session_start();

// Validamos que te gamos un metodo POST
if($_SERVER['REQUEST_METHOD']=='POST'){
 
 // Añadimos la conexion que esta dentro de administracion
 require_once 'administracion/config/conexion.php';

 // Recogemos el valor de las variables
 $email    = $_POST['email'];
 $password = $_POST['password'];

 // Ciframos la contraseña con el algoritmo sha512
 $password = hash('sha512' , $password);

 try {
  $busqueda="SELECT id_usuario, u.id_rol, nombre_rol, nombre_usuario, telefono, correo FROM  usuarios u inner join rol r on u.id_rol = r.id_rol WHERE correo='". $email  ."' AND password='". $password ."' AND estado_usuario = 'A'; ";
  $resultado_busqueda = $conexion->query($busqueda) or die (mysqli_error($conexion));
  $dato = $resultado_busqueda->fetch_assoc();

  // Si los datos de la consulta en la posición 'id_usuario'
  // Son validos, guardamos los datos en sesiones.
  if ($dato['id_usuario'] != null) {
   $_SESSION['id_usuario']     = $dato['id_usuario'];
   $_SESSION['id_rol']         = $dato['id_rol'];
   $_SESSION['nombre_rol']     = $dato['nombre_rol'];
   $_SESSION['nombre_usuario'] = $dato['nombre_usuario'];
   $_SESSION['telefono']       = $dato['telefono'];
   $_SESSION['correo']         = $dato['correo'];

   // Redireccionamos al index de administracion 
   // Con las variables ya creadas
   header('location: administracion/index.php');
  }else{
   // De lo contrario, redireccionamos a la misma pagina
   // Con un error en la url
   header('location: administracion.php?usuario=error');
  }

 } catch (Exception $e) {
   // Si existe un error fuera de la consulta anterior
   // Mandamos un error con la url distinto
  header('location: administracion.php?error=inicio');
 }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
 <?php require 'inc/meta.php'; ?>
</head>
<body>
 <!-- ESTRUCTURA 1 | BARRA DE NAVEGACION -->
 <?php require 'inc/header.php'; ?>

 <!-- ESTRUCTURA 7 | LOGIN -->
 <section id="login">
  <form name="login" class="frmLogin" method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">

     <?php if (isset($_GET['error'])): ?>
      <p class="alerta">Error inesperado en el sistema</p>
     <?php endif ?>

     <?php if (isset($_GET['usuario'])): ?>
      <p class="alerta">Usuario desconocido<br/>Revise sus credenciales</p>
     <?php endif ?>

     <?php if (isset($_GET['inicio'])): ?>
      <p class="alerta">Inicie sesión para tener acceso</p>
     <?php endif ?>

     <?php if (isset($_GET['acceso'])): ?>
      <p class="alerta">Su rol no es compatible<br/>con esta área de trabajo</p>
     <?php endif ?>

     <?php if (isset($_GET['proceso'])): ?>
      <p class="alerta">Se produjo un error al crear la base de datos</p>
     <?php endif ?>

     <?php if (isset($_GET['salir'])): ?>
      <p class="success">Se cerro sesión correctamente</p>
     <?php endif ?>

     <?php if (isset($_GET['database'])): ?>
      <p class="success">Se creo la base de datos exitosamente</p>
     <?php endif ?>

   <h2>Iniciar sesión</h2>
   <div>
    <label id="email">Correo electrónico:</label>
    <input type="email" name="email" class="email" id="email" required="on" onkeypress="validarCorreo(this)">
    <p class="campos_alerta" id="alertaE"></p>
   </div>
   <div>
    <label for="pw">Contraseña:</label>
    <input type="password" name="password" class="pw" id="pw" required="on" onkeypress="longitudClave(this, 5)">
    <p class="campos_alerta" id="alertaP"></p>
   </div>
   <input type="submit" name="enviar" class="login-proceso" id="login-proceso" value="Iniciar">
  </form>

 </section>

  <div class="cont-db">
    (Crear base de datos, <a href="alpaso_db.php" target="_black"> aquí</a>)
  </div>

 <!-- ESTRUCTURA 6 | FO0TER / PIE DE PAGINA -->
 <?php require 'inc/footer.php'; ?>
</body>
</html>