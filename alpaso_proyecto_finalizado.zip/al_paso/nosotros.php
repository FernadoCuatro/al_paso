<!DOCTYPE html>
<html lang="es">
<head>
 <?php require 'inc/meta.php'; ?>
</head>
<body>
 <!-- ESTRUCTURA 1 | BARRA DE NAVEGACION -->
 <?php require 'inc/header.php'; ?>

 <!-- ESTRUCTURA 3 | NOSOTROS -->
 <section class="nosotros">
  <div class="titulo-nosotros">
   <h1>Sobre Nosotros</h1>
  </div>
  <article class="cajas-contenido">
   <div class="imagen">
    <img src="imagenes/new-quienes-somos2.png" alt="Quienes somos" />
   </div>
   <div class="contenido-parrafo">
    <p>
     Al paso nace con el propósito de abarcar el mercado en el rubro de las tiendas de conveniencia. Somos una tienda de conveniencia con ventas enfocadas en los establecimientos en gasolineras, con el propósito de ofrecer la venta de snacks, de comidas rápidas y bebidas frías o calientes. Nuestra finalidad es brindarle la facilidad y sencillez para todo usuario de que abastezca su automóvil gasolineras y al público en general a nuestros productos de alta demanda.
    </p>
   </div>
  </article>
  <article class="cajas-contenido">
   <div class="imagen">
    <img src="imagenes/new-mision2.png" alt="Misión" />
   </div>
   <div class="contenido-parrafo">
    <p>
     En Al Paso, tenemos como misión la mejora continua de nuestros servicios, de esta manera nuestros clientes obtienen una mejor atención de nuestros empleados gracias al diseño intuitivo y sencillo de nuestro sistema administrativo. Al encontrarnos en una gasolinera, queremos que nuestros servicios estén disponibles a nuestros clientes en todo tipo de ocasión, con la mejor atención y fluidez que nuestra tienda ofrece. Recuerda: <b>Donde tu vayas, estamos contigo.</b>
    </p>
   </div>
  </article>
  <article class="cajas-contenido">
   <div class="imagen">
    <img src="imagenes/new-vision2.png" alt="Visión" />
   </div>
   <div class="contenido-parrafo">
    <p>
     Nuestra visión cómo Al paso es ser la mejor tienda de conveniencia a nivel nacional, siendo una empresa líder en el rubro de las tiendas de conveniencia, manteniendo altos niveles de calidad para nuestros clientes, cuidando el talento humano y nuestra relación con los proveedores. Pretendemos expandirnos primeramente en gasolineras estratégicas, para estar siempre disponibles a la orden de nuestros clientes.
    </p>
   </div>
  </article>
 </section>

 <!-- ESTRUCTURA 6 | FO0TER / PIE DE PAGINA -->
 <?php require 'inc/footer.php'; ?>
</body>
</html>