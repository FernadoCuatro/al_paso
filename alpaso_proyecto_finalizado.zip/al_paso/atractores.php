<!DOCTYPE html>
<html lang="es">
<head>
 <?php require 'inc/meta.php'; ?>
</head>
<body>
 <!-- ESTRUCTURA 1 | BARRA DE NAVEGACION -->
 <?php require 'inc/header.php'; ?>

 <!-- ESTRUCTURA  | ECOLOGICO -->
 <section id="ecologico">
  <div class="contenedor-eco">
   <div class="encabezado">
    <div class="titulo-eco1">
     <h1>Eco-Al paso</h1>
    </div>
    <div class="titulo-eco2"><img class="paso-ecologico" src="imagenes/al-paso-ecologico.png" /></div>
   </div>
   <div class="centrar">
    En Al Paso la sostenibilidad ambiental es sumamente importante, por ello nos basamos
    en tres aspectos importantes:<br><br>
   </div>
   <div class="imagenes-ecos">
    <div class="tamaño-celda-imagen-eco">
     <img class="tamaño-biodegradable" src="imagenes/biodegradable2.png">
    </div>
    <div class="tamaño-celda-imagen-eco">
     <img class="tamaño-ambiente" src="imagenes/medio-ambiente.png">
    </div>
    <div class="tamaño-celda-imagen-eco">
     <img class="tamaño-reforestacion" src="imagenes/reforestacion.png">
    </div>
   </div>
   <div class="contenedor-titulos-eco">
    <div class="subtitulos-e">Productos</div>
    <div class="subtitulos-e">Medio Ambiente</div>
    <div class="subtitulos-e">Reforestación</div>
   </div>
   <div class="contenedor-descripcion-eco">
    <div class="descripcion-e">
     Para conseguir que Al Paso brinde un aporte significativo al medio ambiente,
     tenemos en cuenta que nuestra materia prima sean insumos de limpieza
     certificados como sostenibles y el uso de productos biodegradables tales como bolsas, platos,
     vasos, cubiertos, etc.
    </div>
    <div class="descripcion-e">
     En esta temática tenemos en cuenta el ecodiseño, uso de materiales y
     equipos de cocina sostenibles, logística y transporte de alimentos que reduzcan el impacto
     ambiental, control del uso de energía, agua y gas.
    </div>
    <div class="descripcion-e">
     Siempre año con año ayudamos con toda la voluntad, a diferentes ONG’s que se
     encargan de la reforestación de bosques y preservación del medio ambiente.
    </div>
   </div>
  </div>
 </section>

 <!-- ESTRUCTURA  | PRODUCTOS DE CALIDAD -->
 <section id="calidad">
  <div class="contenedor-calidad">
   <div class="negrita-centro">
    <h1>Productos de calidad</h1>
   </div>
   <div class="centrar">
    En Al Paso tenemos nuestro firme compromiso de dar la máxima calidad y satisfacción a
    nuestros clientes para que cada visita a nuestro local se convierta en momentos de
    satisfacción; para ello, nos planteamos algunos principios básicos a cumplir:<br><br>
   </div>
   <div class="contenedor-imagenes-calidad">
    <div class="tamaño-celda-imagen-calidad">
     <img class="tamaño-fresca" src="imagenes/comida-fresca.png" alt="al-paso-white">
    </div>
    <div class="tamaño-celda-imagen-calidad">
     <img class="tamaño-calidad" src="imagenes/producto-calidad.png" alt="al-paso-white">
    </div>
    <div class="tamaño-celda-imagen-calidad">
     <img class="tamaño-proveedor" src="imagenes/proveedor.png" alt="proveedor">
    </div>
   </div>
   <div class="contenedor-titulos-calidad">
    <div class="subtitulos-c">Calidad</div>
    <div class="subtitulos-c">Normativas</div>
    <div class="subtitulos-c">Proveedores</div>
   </div>
   <div class="contenedor-descripcion-calidad">
    <div class="descripcion-calidad">
     La calidad de nuestros productos debe ser la mejor, de tal manera que nuestros proveedores
     nos brindan lo mas fresco del mercado para que nuestros clientes puedan degustar de la
     mejor manera posible de ella.
    </div>
    <div class="descripcion-calidad">
     Cada producto debe cumplir con todas las normativas alimentarias exigibles, respetando
     siempre las normas de seguridad en cuanto a los estándares de temperatura,
     almacenamiento, limpieza de sus depósitos de resguardo, bioseguridad etc.
    </div>
    <div class="descripcion-calidad">
     Todos nuestros productos son suministrados por empresas 100%
     salvadoreñas, haciendo de esto una oportunidad de crecimiento para aquellos nuevos
     microempresarios, ayudando al crecimiento económico
     del país y a la vez contribuyendo a su imagen dando una excelente referencia de su labor.
    </div>
   </div>
  </div>
 </section>

 <!-- ESTRUCTURA  | AYUDA ALIMENTARIA -->
 <section id="ayuda-alimentaria">
  <div class="contenedor-alimentaria">
   <div class="imagen-alimentaria">
    <img class="donacion" src="imagenes/ayuda-alimentaria.png">
   </div>
   <div class="descripcion-alimentaria">
    <div colspan="2" class="negrita-centro">
     <h1>Ayuda alimentaria</h1>
    </div>
    <div class="justificar">
     Nos llena de satisfacción el poder compartir, por eso hemos diseñado un programa de ayuda
     alimentaria a instituciones benéficas sin fines de lucro, el cual consiste en la donación de la comida
     excedente a asilos, iglesias, entre otros; verificando minuciosamente siempre el buen estado de
     ésta, para que no cause ningún perjuicio a nuestros beneficiarios. Las donaciones se realizan con
     el fin contribuir a la disminución de la desnutrición y la pobreza, de las diferentes comunidades
     donde operamos.
    </div>
   </div>
  </div>
 </section>

 <!-- ESTRUCTURA 6 | FO0TER / PIE DE PAGINA -->
 <?php require 'inc/footer.php'; ?>
</body>
</html>