<?php 
session_start();

function comprobar_sesion(){
		if(!isset($_SESSION['id_usuario'])){
	 header('Location: ../administracion.php?inicio=error');
	}
}

function comprobar_rol_vendedor(){
	$rol = $_SESSION['id_rol'];
		if($rol != 1){
	 header('Location: ../administracion.php?acceso=off');
	}
}

function comprobar_rol_gerente(){
	$rol = $_SESSION['id_rol'];
		if($rol != 2){
	 header('Location: ../administracion.php?acceso=off');
	}
}

function comprobar_rol_administrador(){
	$rol = $_SESSION['id_rol'];
		if($rol != 3){
	 header('Location: ../administracion.php?acceso=off');
	}
}

?>	