<nav class="navbar navbar-default">
 <div class="container-fluid">
  <ul class="nav navbar-nav navbar-right">
   <li><a><i class="fas fa-user-cog"></i> Nombre del rol del usuario</a></li>
   <li><a><i class="far fa-user-circle"></i> Correo electronico del usuario</a></li>
   <li><a href="../administracion.php"><i class="fas fa-sign-out-alt"></i> Cerrar sesión</a></li>
  </ul>
 </div>
</nav>