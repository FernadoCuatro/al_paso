
 <!-- API para utilizar iconos de fontawesome -->
 <script src="https://kit.fontawesome.com/d21a3be417.js"></script>

 <!-- scripts personalizados -->
 <script src="js/scripts.js"></script>