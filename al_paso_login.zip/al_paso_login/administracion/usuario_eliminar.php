<?php
include 'config/funciones.php';

	if (isset($_GET['id_usuario'])) {
	 $consulta = eliminar($_GET['id_usuario']);
	}else{
	 header('Location: usuario_listar.php');
	}

	function eliminar($id){
 	require_once 'config/conexion.php';

	}

mysqli_close($conexion);
?>
