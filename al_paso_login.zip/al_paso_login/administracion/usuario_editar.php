<?php
include 'config/funciones.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
 require_once 'config/conexion.php';

 mysqli_close($conexion);
}

if (isset($_GET['id_usuario'])) {
 $consulta = actualizar($_GET['id_usuario']);
}else{
 header('Location: usuario_listar.php');
}

function actualizar($id) {
 require_once 'config/conexion.php';

}

?>

<!DOCTYPE html>
<html lang="es">

<head>
 <?php require 'inc/meta.php'; ?>
</head>

<body>
 <div id="vista">
  <?php require 'inc/header.php'; ?>
  <!-- Contenido general -->
  <div id="contenido-general">
   <?php require 'inc/header_superior.php'; ?>

   <!-- Espacio para el contenido a agregar -->
   <div class="container-fluid">
    <div class="contenido-entrada">
     <article class="texto-base">
      <h1 class="nombre-proceso">Editar usuario</h1>
      <h4 class="nombre-modulo">Módulo usuario</h4>
     </article>
     <!-- Todo listo, mucha suerte; recuerda las indicaciones. -->
     <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" name="usuario_editar" method="post" class="formulario" id="formulario">
      <input type="hidden" name="id_usuario" id="id_usuario" value="<?php echo $_GET['id_usuario'] ?>">

      <!--Grupo Rol estbalecido usuario:-->
      <div class="formulario-rol" id="rol-usuario">
       <label for="usuario" class="formulario-label">Rol estbalecido usuario:</label>
       <div class="formulario-grupo-input">
        <select name="usuario_rol" id="usuarios" class="select-usuario">
         <option value="1">Vendedor</option>
         <option value="2">Gerente</option>
         <option value="3">Administrador</option>
        </select>
       </div>
      </div><br>
      <div class="form-label">
       <!--Grupo nombre completo:-->
       <div id="grupo-nombre">
        <label for="nombre" class="formulario-label">Nombre completo:</label>
        <div>
         <input type="text" class="fomulario-input" name="usuario_nombre" placeholder="Ej. Juan Perez" onkeypress="validarnombre(this,10)" minlength="10" maxlength="50" required="on" value="<?php echo $consulta[0] ?>">
         <p class="formulario-input-error" id="error-nombre"></p>
        </div>
       </div>
       <!--Grupo correo electronico -->
       <div id="grupo-email">
        <label for="correo" class="formulario-label">Correo Electronico:</label>
        <div>
         <input type="mail" class="fomulario-input" name="usuario_email" placeholder="ejemplo@mail.com" onkeypress="validarcorreo(this)" value="<?php echo $consulta[1] ?>">
         <p class="formulario-input-error" id="alertacorreo"></p>
        </div>
       </div>
      </div><br>
      <div class="form-label2">
       <!--Grupo DUI-->
       <div id="grupo-dui">
        <label for="dui" class="formulario-label">DUI:</label>
        <div>
         <input type="text" class="fomulario-input" name="usuario_dui" id="dui" placeholder="00000000-0" onkeypress="this.value=validardui(this.value)" maxlength="10" required="on" value="<?php echo $consulta[2] ?>">
         <p class="formulario-input-error" id="error-dui"></p>
        </div>
       </div>
       <!--Grupo NIT-->
       <div id="grupo-nit">
        <label for="nit" class="formulario-label">NIT:</label>
        <div>
         <input type="tex" class="fomulario-input" name="usuario_nit" id="nit" placeholder="0000-00000-000-0" onkeypress="this.value=validarnit(this.value)" maxlength="17" required="on" value="<?php echo $consulta[3] ?>">
         <p class="formulario-input-error" id="error-nit"></p>
        </div>
       </div>
       <!--Grupo telefono-->
       <div id="grupo-telefono">
        <label for="telefono" class="formulario-label">Teléfono:</label>
        <div class="formulario-grupo-input">
         <input type="text" class="fomulario-input" name="usuario_telefono" id="telefono" placeholder="0000-0000" onkeypress="this.value=validartelf(this.value)" onblur="validartelefono(this,8)" maxlength="9" value="<?php echo $consulta[4] ?>">
         <p class="formulario-input-error" id="error-telefono"></p>
        </div>
       </div>
      </div><br>
      <!--Grupo  Estado del usuario:-->
      <div id="estado_usuario">
       <label for="usuario" class="formulario-label">Estado del usuario:</label>
       <div class="formulario-grupo-select">
        <select name="usuario_estado" id="usuario-estado" class="select-usuario">
         <option value="A">Activo</option>
         <option value="I">Inactivo</option>
        </select>
       </div>
      </div>
      <!--Botón para editar el usuario-->
      <div class="btn-usuario-editar">
       <button type="submit" class="editar" id="editar">Editar</button>
      </div>
      <br>
     </form>

     <div class="text-center">
      <a href="usuario_listar.php">Volver</a>
     </div>

    </div>
   </div>
  </div>
 </div>
 
 <script src="js/scripts.js"></script>
</body>

</html>