<?php
session_start();

// Validamos que te gamos un metodo POST
if($_SERVER['REQUEST_METHOD']=='POST'){
 
 // Añadimos la conexion que esta dentro de administracion
 require_once 'administracion/config/conexion.php';

 // Recogemos el valor de las variables


 // Ciframos la contraseña con el algoritmo sha512
 // $password = hash('sha512' , $password);


}

?>
<!DOCTYPE html>
<html lang="es">
<head>
 <?php require 'inc/meta.php'; ?>
</head>
<body>
 <!-- ESTRUCTURA 1 | BARRA DE NAVEGACION -->
 <?php require 'inc/header.php'; ?>

 <!-- ESTRUCTURA 7 | LOGIN -->
 <section id="login">
  <form name="login" class="frmLogin" method="POST" action="administracion/">

     <?php if (isset($_GET['error'])): ?>
      <p class="alerta">Error inesperado en el sistema</p>
     <?php endif ?>

     <?php if (isset($_GET['usuario'])): ?>
      <p class="alerta">Usuario desconocido<br/>Revise sus credenciales</p>
     <?php endif ?>

     <?php if (isset($_GET['inicio'])): ?>
      <p class="alerta">Inicie sesión para tener acceso</p>
     <?php endif ?>

     <?php if (isset($_GET['acceso'])): ?>
      <p class="alerta">Su rol no es compatible<br/>con esta área de trabajo</p>
     <?php endif ?>

     <?php if (isset($_GET['proceso'])): ?>
      <p class="alerta">Se produjo un error al crear la base de datos</p>
     <?php endif ?>

     <?php if (isset($_GET['salir'])): ?>
      <p class="success">Se cerro sesión correctamente</p>
     <?php endif ?>

     <?php if (isset($_GET['database'])): ?>
      <p class="success">Se creo la base de datos exitosamente</p>
     <?php endif ?>

   <h2>Iniciar sesión</h2>
   <div>
    <label id="email">Correo electrónico:</label>
    <input type="email" name="email" class="email" id="email" required="on" onkeypress="validarCorreo(this)">
    <p class="campos_alerta" id="alertaE"></p>
   </div>
   <div>
    <label for="pw">Contraseña:</label>
    <input type="password" name="password" class="pw" id="pw" required="on" onkeypress="longitudClave(this, 5)">
    <p class="campos_alerta" id="alertaP"></p>
   </div>
   <input type="submit" name="enviar" class="login-proceso" id="login-proceso" value="Iniciar">
  </form>

 </section>

  <div class="cont-db">
    (Crear base de datos, <a href="alpaso_db.php" target="_black"> aquí</a>)
  </div>

 <!-- ESTRUCTURA 6 | FO0TER / PIE DE PAGINA -->
 <?php require 'inc/footer.php'; ?>
</body>
</html>