<!-- ESTRUCTURA 1 | BARRA DE NAVEGACION -->
<header id="navegacion">
 <div class="celda-imagen"><img src="imagenes/al-paso.png" class="imagen-barra" alt="al-paso" /></div>
 <nav class="celda-barra">
  <ul>
   <li><a href="index.php" class="enlace-barra">Inicio</a></li>
   <li><a href="nosotros.php" class="enlace-barra">Nosotros</a></li>
   <li><a href="categorias.php" class="enlace-barra">Categorías</a></li>
   <li><a href="ofertas.php" class="enlace-barra">Ofertas</a></li>
   <li><a href="atractores.php" class="enlace-barra">Atractores</a></li>
  </ul>
  <ul>
   <!--<a href="administracion.html"><img class="logo-usuario" src="imagenes/usuario.png" alt="usuario" /></a><br> -->
   <li><a href="administracion.php" class="enlace-barra-usuario">Inicia sesión</a></li>
  </ul>
 </nav>
</header>