<?php
	$Conectado=mysqli_connect("localhost","root","");
	
	$Consulta_0="drop database if exists alpaso_db;";
	$EjecutarConsulta_0=mysqli_query($Conectado, $Consulta_0);
	
	$Consulta="create database alpaso_db;";
	$EjecutarConsulta=mysqli_query($Conectado, $Consulta);

	$conn_contenido = new mysqli('localhost', 'root', '' , 'alpaso_db');
	
	$query = '';
	$sqlScript = file('inc/db_proceso.sql');
	foreach ($sqlScript as $line)  {
	 
	 $startWith = substr(trim($line), 0 ,2);
	 $endWith = substr(trim($line), -1 ,1);
	 
	 if (empty($line) || $startWith == '--' || $startWith == '/*' || $startWith == '//') {
	    continue;
	 }
	 
	 $query = $query . $line;
	 if ($endWith == ';') {
	   mysqli_query($conn_contenido,$query) or die(header('location: administracion.php?proceso=database'));
	   $query= '';
	 }
	}

	header('location: administracion.php?database=complete');

	mysqli_close($Conectado);
?>
